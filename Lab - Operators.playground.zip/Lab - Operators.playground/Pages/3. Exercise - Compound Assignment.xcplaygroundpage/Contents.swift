/*:
## Exercise - Compound Assignment
 
 Declare a variable whose value begins at 10. Using addition, update the value to 15 using the compound assignment operator. Using multiplication, update the value to 30 using compound assignment. Print out the variable's value after each assignment.
 */
var num1 = 10
num1 += 5
print("Num1 after add = \(num1)")
num1 *= 2
print("Num1 after multiply = \(num1)")

/*:
 Create a variable called `piggyBank` that begins at 0. You will use this to keep track of money you earn and spend. For each point below, use the right compound assignment operator to update the balance in your piggy bank.
 
- Your neighbor gives you 10 dollars for mowing her lawn
- You earn 20 more dollars throughout the week doing odd jobs
- You spend half your money on dinner and a movie
- You triple what's left in your piggy bank by washing windows
- You spend 3 dollars at a convenience store
 
 Print the balance of your piggy bank after each step.
 */
// Im sorry I will replace piggyBank with myBank :)
var myBank = 0
myBank += 10
print("My bank balance after mowing the lawn = \(myBank) ")
myBank += 20
print("My bank balance after doing my jobs = \(myBank) ")
myBank /= 2
print("My bank balance after the dinner = \(myBank) ")
myBank *= 3
print("My bank balance after washing windows = \(myBank) ")
myBank -= 3
print("My bank balance after 3 dollar spend = \(myBank) ")

/*:
[Previous](@previous)  |  page 3 of 8  |  [Next: App Exercise - Counting](@next)
 */
