print (true)

//:  2. `9 != 9`
print (false)

//:  3. `47 > 90`
print (false)

//:  4. `47 < 90`
print (true)

//:  5. `4 <= 4`
print (true)

//:  6. `4 >= 5`
print (false)

//:  7. `(47 > 90) && (47 < 90)`


//:  8. `(47 > 90) || (47 < 90)`
print (false)

//:  9. `!true`
print (false)

/*:
page 1 of 9  |  [Next: Exercise - If and If-Else Statements](@next)
 */
