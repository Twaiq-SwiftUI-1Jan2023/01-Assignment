let leaguePosition = 1
switch leaguePosition {
case 1 :
    print ("Champions!")
case 2 :
    print ("Runners up")
case 3:
    print ("Third place")
default :
    print ("Bad season!")
}

//:  Write a new `switch` statement that prints "Medal winner" if `leaguePosition` is within the range of 1-3. Otherwise, print "No medal awarded."
switch leaguePosition {
case 1 ... 3 :
    print ("Madal winner")
default :
    print ("No medal awarded")
}

/*:
[Previous](@previous)  |  page 6 of 9  |  [Next: App Exercise - Heart Rate Zones](@next)
 */
