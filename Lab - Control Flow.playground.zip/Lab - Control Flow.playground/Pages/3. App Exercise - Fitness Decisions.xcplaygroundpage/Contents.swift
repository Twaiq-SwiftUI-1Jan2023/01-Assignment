let stepGoal = 10000
if stepGoal > 5000 {
    print ("You're almost halfway there !")
}
else {
    print ("You're over halfway there !")
}
//:  Now create a new, but similar, if-else-if statement that prints "Way to get a good start today!" if `steps` is less than a tenth of `stepGoal`, prints "You're almost halfway there!" if `steps` is less than half of `stepGoal`, and prints "You're over halfway there!" if `steps` is greater than half of `stepGoal`.
var stepGoal1 = 10000
if stepGoal1 < 1000 {
    print ("Way to get a good start today!")
}
else if stepGoal1 > 5000 {
    print ("You're almost halfway there !")
}
else {
    print ("You're over halfway there !")
}

/*:
[Previous](@previous)  |  page 3 of 9  |  [Next: Exercise - Boolean Practice](@next)
 */
